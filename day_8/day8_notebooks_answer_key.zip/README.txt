
Answer Key Branch – Day 8
-------------------------
• prompt_injection_answer.ipynb – shows both exploit and fix.
• Extend this pattern to other labs by comparing pre‑patched vs. patched cells.
